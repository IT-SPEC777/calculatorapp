// oauth-m2m: консольный M2M-клиент OAuth 2.0 (client_credentials).
// Режимы: private_key_jwt (RFC 7523) и mTLS / tls_client_auth (RFC 8705).
//
// Конфигурация (по возрастанию приоритета):
//   appsettings.json  <  --config <файл.json>  <  переменные окружения (OAuth__ClientId)  <  аргументы (--OAuth:ClientId=...)
//
// Служебные ключи:
//   --config=<путь>        дополнительный JSON-файл с секцией "OAuth"
//   --PrintToken=true      вывести access_token целиком (по умолчанию — маска)
//   --PrintJwks=true       вывести публичный JWKS из приватного ключа и выйти
//
// Коды возврата: 0 — успех, 1 — ошибка получения токена/ключей, 2 — ошибка конфигурации, 130 — отмена.
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using OAuthM2M.Client;
using OAuthM2M.Client.Security;
using OAuthM2M.Client.Tokens;

var builder = Host.CreateApplicationBuilder(new HostApplicationBuilderSettings
{
    Args = args,
    // appsettings.json лежит рядом с dll, а не в текущем каталоге
    ContentRootPath = AppContext.BaseDirectory
});

var extraConfig = builder.Configuration["config"];
if (!string.IsNullOrWhiteSpace(extraConfig))
{
    builder.Configuration
        .AddJsonFile(Path.GetFullPath(extraConfig), optional: false, reloadOnChange: false)
        .AddEnvironmentVariables()   // повторно, чтобы сохранить приоритет env и аргументов над файлом
        .AddCommandLine(args);
}

using var cts = new CancellationTokenSource();
Console.CancelKeyPress += (_, e) =>
{
    e.Cancel = true;
    cts.Cancel();
};

try
{
    // --- служебный режим: публичный JWKS ---
    if (builder.Configuration.GetValue<bool>("PrintJwks"))
    {
        var o = builder.Configuration.GetSection(OAuthClientOptions.SectionName).Get<OAuthClientOptions>()
                ?? new OAuthClientOptions();
        Console.WriteLine(JwksExporter.ExportPublicJwks(o));
        return 0;
    }

    var printToken = builder.Configuration.GetValue<bool>("PrintToken");

    builder.Services.AddOAuthM2MClient(builder.Configuration);
    using var host = builder.Build();

    // Обращение к IOptions<> запускает валидацию настроек.
    var options = host.Services.GetRequiredService<IOptions<OAuthClientOptions>>().Value;
    var client = host.Services.GetRequiredService<IOAuthTokenClient>();

    var token = await client.RequestTokenAsync(cts.Token);

    Console.WriteLine($"Режим:        {options.AuthMethod}");
    Console.WriteLine($"token_type:   {token.TokenType}");
    Console.WriteLine($"expires_in:   {token.ExpiresIn} c");
    Console.WriteLine($"access_token: {SecretMasker.Mask(token.AccessToken)}");
    if (printToken)
    {
        Console.WriteLine();
        Console.WriteLine(token.AccessToken);
    }

    return 0;
}
catch (OptionsValidationException ex)
{
    Console.Error.WriteLine("Ошибка конфигурации:");
    foreach (var failure in ex.Failures)
    {
        Console.Error.WriteLine($"  - {failure}");
    }

    return 2;
}
catch (InvalidOperationException ex)
{
    Console.Error.WriteLine($"Ошибка конфигурации: {ex.Message}");
    return 2;
}
catch (OperationCanceledException)
{
    Console.Error.WriteLine("Операция отменена.");
    return 130;
}
catch (Exception ex)
{
    Console.Error.WriteLine($"Ошибка: {ex.Message}");
    return 1;
}
