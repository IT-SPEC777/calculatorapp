namespace OAuthM2M.Client.Tokens;

/// <summary>Сбой получения токена (сеть, таймаут, ответ сервера, некорректный JSON).</summary>
public sealed class TokenRequestException : Exception
{
    public TokenRequestException(string message, int? statusCode = null, string? error = null, Exception? inner = null)
        : base(message, inner)
    {
        StatusCode = statusCode;
        Error = error;
    }

    /// <summary>HTTP-статус ответа, если он был получен.</summary>
    public int? StatusCode { get; }

    /// <summary>Значение поля error из ответа (invalid_client и т. п.).</summary>
    public string? Error { get; }
}
