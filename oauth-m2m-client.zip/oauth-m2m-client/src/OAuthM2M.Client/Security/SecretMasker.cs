namespace OAuthM2M.Client.Security;

/// <summary>Маскирование токенов для логов/консоли.</summary>
public static class SecretMasker
{
    public static string Mask(string? value)
    {
        if (string.IsNullOrEmpty(value))
        {
            return "<empty>";
        }

        return value.Length <= 16
            ? "***"
            : $"{value[..8]}…{value[^4..]} (len={value.Length})";
    }
}
