using System.Security.Cryptography;
using System.Text.Json;
using Microsoft.IdentityModel.Tokens;

namespace OAuthM2M.Client.Security;

/// <summary>
/// Формирует публичный JWKS из приватного ключа — удобно для регистрации ключа
/// в Keycloak / Avanpost FAM по JWKS-документу. Приватная часть в вывод не попадает.
/// </summary>
public static class JwksExporter
{
    private static readonly JsonSerializerOptions Indented = new() { WriteIndented = true };

    public static string ExportPublicJwks(OAuthClientOptions options)
    {
        if (string.IsNullOrWhiteSpace(options.PrivateKeyPath))
        {
            throw new InvalidOperationException("OAuth:PrivateKeyPath не задан.");
        }

        if (string.IsNullOrWhiteSpace(options.KeyId))
        {
            throw new InvalidOperationException("OAuth:KeyId не задан.");
        }

        using var rsa = PrivateKeyLoader.Load(options.PrivateKeyPath, options.PrivateKeyPassword);
        var p = rsa.ExportParameters(includePrivateParameters: false);

        var jwks = new
        {
            keys = new[]
            {
                new
                {
                    kty = "RSA",
                    use = "sig",
                    alg = "RS256",
                    kid = options.KeyId,
                    n = Base64UrlEncoder.Encode(p.Modulus!),
                    e = Base64UrlEncoder.Encode(p.Exponent!)
                }
            }
        };

        return JsonSerializer.Serialize(jwks, Indented);
    }
}
