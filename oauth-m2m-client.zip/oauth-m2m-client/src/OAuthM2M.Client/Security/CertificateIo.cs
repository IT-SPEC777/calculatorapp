using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace OAuthM2M.Client.Security;

/// <summary>Обёртки над загрузкой сертификатов с учётом API .NET 9+ (X509CertificateLoader) и .NET 8.</summary>
internal static class CertificateIo
{
    public static X509Certificate2 LoadPkcs12(string path, string? password)
    {
#if NET9_0_OR_GREATER
        return X509CertificateLoader.LoadPkcs12FromFile(path, password);
#else
        return new X509Certificate2(path, password);
#endif
    }

    public static X509Certificate2 LoadPkcs12(byte[] data, string? password)
    {
#if NET9_0_OR_GREATER
        return X509CertificateLoader.LoadPkcs12(data, password);
#else
        return new X509Certificate2(data, password);
#endif
    }

    /// <summary>Загружает один или несколько сертификатов (PEM-бандл или одиночный DER) без приватных ключей.</summary>
    public static X509Certificate2Collection LoadCertificates(string path)
    {
        var bytes = File.ReadAllBytes(path);
        var collection = new X509Certificate2Collection();
        var text = Encoding.ASCII.GetString(bytes);

        if (text.Contains("-----BEGIN CERTIFICATE-----", StringComparison.Ordinal))
        {
            collection.ImportFromPem(text);
        }
        else
        {
#if NET9_0_OR_GREATER
            collection.Add(X509CertificateLoader.LoadCertificate(bytes));
#else
            collection.Add(new X509Certificate2(bytes));
#endif
        }

        return collection;
    }
}
