using System.Security.Cryptography;

namespace OAuthM2M.Client.Security;

/// <summary>Загрузка приватного ключа RSA из PEM-файла.</summary>
public static class PrivateKeyLoader
{
    public const int MinimumKeySizeBits = 2048;

    /// <exception cref="FileNotFoundException">Файл не найден.</exception>
    /// <exception cref="CryptographicException">Ключ повреждён или короче 2048 бит.</exception>
    public static RSA Load(string path, string? password = null)
    {
        if (!File.Exists(path))
        {
            throw new FileNotFoundException($"Файл приватного ключа не найден: {path}", path);
        }

        var rsa = RSA.Create();
        try
        {
            var pem = File.ReadAllText(path);
            if (string.IsNullOrEmpty(password))
            {
                rsa.ImportFromPem(pem);                 // PKCS#8 / PKCS#1
            }
            else
            {
                rsa.ImportFromEncryptedPem(pem, password);
            }

            if (rsa.KeySize < MinimumKeySizeBits)
            {
                throw new CryptographicException(
                    $"Размер ключа {rsa.KeySize} бит; требуется RSA-{MinimumKeySizeBits} или больше.");
            }

            return rsa;
        }
        catch
        {
            rsa.Dispose();
            throw;
        }
    }
}
