using System.Globalization;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;

namespace OAuthM2M.Client.Security;

/// <summary>
/// Собирает и подписывает client_assertion (RFC 7523): RS256, заголовок с kid,
/// claims iss/sub/aud/jti/iat/nbf/exp. Ключ загружается лениво и один раз.
/// </summary>
public sealed class ClientAssertionFactory : IClientAssertionFactory, IDisposable
{
    private readonly OAuthClientOptions _options;
    private readonly TimeProvider _time;
    private readonly JwtSecurityTokenHandler _handler = new();
    private readonly Lazy<(RSA Rsa, SigningCredentials Credentials)> _key;

    public ClientAssertionFactory(IOptions<OAuthClientOptions> options, TimeProvider time)
    {
        _options = options.Value;
        _time = time;
        _key = new Lazy<(RSA Rsa, SigningCredentials Credentials)>(LoadKey);
    }

    public string Create()
    {
        var now = _time.GetUtcNow().UtcDateTime;
        var iat = new DateTimeOffset(now).ToUnixTimeSeconds();

        var claims = new List<Claim>
        {
            new(JwtRegisteredClaimNames.Sub, _options.ClientId),
            new(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString("D")),   // защита от replay
            new(JwtRegisteredClaimNames.Iat, iat.ToString(CultureInfo.InvariantCulture), ClaimValueTypes.Integer64)
        };

        var jwt = new JwtSecurityToken(
            issuer: _options.ClientId,                                   // iss = client_id
            audience: _options.EffectiveAudience,                         // aud = токен-эндпоинт (или issuer)
            claims: claims,
            notBefore: now,
            expires: now.AddSeconds(_options.AssertionLifetimeSeconds),
            signingCredentials: _key.Value.Credentials);

        return _handler.WriteToken(jwt);
    }

    private (RSA Rsa, SigningCredentials Credentials) LoadKey()
    {
        if (string.IsNullOrWhiteSpace(_options.PrivateKeyPath))
        {
            throw new InvalidOperationException("OAuth:PrivateKeyPath не задан.");
        }

        var rsa = PrivateKeyLoader.Load(_options.PrivateKeyPath, _options.PrivateKeyPassword);

        // KeyId попадает в заголовок JWT как "kid".
        var securityKey = new RsaSecurityKey(rsa) { KeyId = _options.KeyId };
        var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.RsaSha256); // RS256
        return (rsa, credentials);
    }

    public void Dispose()
    {
        if (_key.IsValueCreated)
        {
            _key.Value.Rsa.Dispose();
        }
    }
}
