namespace OAuthM2M.Client.Security;

/// <summary>Создаёт подписанный client_assertion (JWT).</summary>
public interface IClientAssertionFactory
{
    /// <summary>Новый JWT: уникальный jti, короткий exp. Вызывается на каждый запрос токена.</summary>
    string Create();
}
