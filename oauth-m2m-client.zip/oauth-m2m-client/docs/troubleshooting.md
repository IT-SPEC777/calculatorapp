# Диагностика

Клиент выводит статус HTTP и поля `error` / `error_description` из ответа сервера. Токены и client_assertion в логи не попадают.

| Симптом | Вероятная причина | Что сделать |
|---|---|---|
| `Ошибка конфигурации: ...` (код 2) | не заданы обязательные параметры | прочтите список после двоеточия; пример — `config/*.json` |
| `invalid_client` + «signature»/«Unable to load public key» | на сервере не тот ключ/сертификат; не совпадает `kid` | загрузите актуальный `client.crt`; сверьте `OAuth:KeyId` с `kid` в JWKS (`--PrintJwks=true`); для Keycloak попробуйте JWKS URL |
| `invalid_client` + «audience» | `aud` не тот | задайте `OAuth:Audience`: токен-эндпоинт или issuer (Keycloak 26 — рекомендуется issuer) |
| `invalid_client` + «expired» / «not yet valid» | рассинхрон часов | синхронизируйте время (NTP); при дрейфе > нескольких секунд JWT отвергается |
| `invalid_client` + «jti» / «already used» | повтор assertion | клиент всегда создаёт новый jti; проверьте, что нет прокси-повторов запроса |
| `unauthorized_client` | клиенту не разрешён `client_credentials` | Keycloak: включите «Service accounts roles»; FAM: включите грант `client_credentials` |
| `invalid_scope` | запрошен недоступный scope | уберите `OAuth:Scope` или выдайте scope клиенту |
| `invalid_client` в режиме mTLS при валидном сертификате | сертификат не дошёл до сервера (прокси) или Subject DN не совпал | настройте проброс клиентского сертификата (nginx/HAProxy lookup); сверьте Subject DN с настройкой клиента |
| `Сетевая или TLS-ошибка: The SSL connection could not be established` | сервер подписан непубличным УЦ | укажите `OAuth:ServerCaCertificatePath` |
| `...RemoteCertificateNameMismatch` | имя в URL не совпадает с SAN сертификата сервера | используйте FQDN из сертификата; имя хоста проверяется всегда |
| `Файл приватного ключа не найден` | путь относителен текущего каталога | запускайте из корня репозитория или задайте абсолютный путь |
| `Размер ключа 1024 бит; требуется RSA-2048` | слабый ключ | `./scripts/gen-keys.sh` |
| `ImportFromPem ... encrypted` | PEM зашифрован, пароль не задан | `OAuth__PrivateKeyPassword` |
| `Таймаут запроса к серверу авторизации` | сеть/файрвол | `OAuth:HttpTimeoutSeconds`; проверьте доступность `curl -v <token_endpoint>` |
| `NU1102`/`NU1101` при `dotnet restore` | пакет не найден (нет доступа к nuget.org или версия в `Directory.Packages.props` недоступна) | проверьте `nuget.config` (внутренний прокси), подберите доступную версию: `dotnet package search <имя>` |
| Windows: mTLS с PEM-ключом не работает | эфемерные ключи | клиент пересохраняет PEM-пару через PKCS#12 в памяти; либо используйте PFX |

Проверка без клиента (curl, режим JWT) — получите JWT любым способом и отправьте:

```bash
curl -v -d grant_type=client_credentials -d client_id=my-service \
  -d client_assertion_type=urn:ietf:params:oauth:client-assertion-type:jwt-bearer \
  -d "client_assertion=<JWT>" "<token_endpoint>"
```

Посмотреть содержимое client_assertion (без подписи): вставьте JWT на jwt.io **только тестовый**, либо
`cut -d. -f1,2 | tr '.' '\n' | base64 -d`. Заголовок должен содержать `alg=RS256` и `kid`.
