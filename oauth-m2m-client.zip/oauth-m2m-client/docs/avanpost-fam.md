# Avanpost FAM: настройка и запуск

> Публичной документации Avanpost FAM по настройке `private_key_jwt` / mTLS для OAuth-клиентов я не нашёл,
> поэтому здесь — **чек-лист требований**, а не пошаговая инструкция по экрану админки.
> Названия разделов и полей зависят от версии FAM: сверяйтесь с руководством администратора вашей версии или обратитесь к вендору.
> Всё, что нужно клиенту, проверяется через discovery-документ — это надёжнее любой инструкции.

## 1. Узнайте возможности сервера (discovery)

```bash
curl -s https://fam.example.local/.well-known/openid-configuration | jq \
  '{issuer, token_endpoint, jwks_uri, token_endpoint_auth_methods_supported, token_endpoint_auth_signing_alg_values_supported, grant_types_supported}'
```

(Путь discovery может отличаться — например, содержать имя домена/приложения. Возьмите ссылку из настроек FAM.)

Что смотреть:

| Поле | Что значит для вас |
|---|---|
| `token_endpoint` | значение для `OAuth:TokenEndpoint` |
| `issuer` | второй кандидат для `OAuth:Audience` |
| `token_endpoint_auth_methods_supported` | должен содержать `private_key_jwt` (режим JWT) и/или `tls_client_auth` / `self_signed_tls_client_auth` (режим mTLS) |
| `token_endpoint_auth_signing_alg_values_supported` | должен содержать `RS256` |
| `grant_types_supported` | должен содержать `client_credentials` |

Если нужного метода в списке нет — режим на этом сервере не включён или не поддерживается вашей версией; решается на стороне FAM.

## 2. private_key_jwt

На стороне FAM нужно:

1. Зарегистрировать **конфиденциальный OAuth/OIDC-клиент** с `client_id` = `OAuth:ClientId`, разрешённым грантом `client_credentials`.
2. Выбрать метод аутентификации клиента на токен-эндпоинте **private_key_jwt**, алгоритм подписи **RS256**.
3. Зарегистрировать публичный ключ клиента одним из способов (какие доступны — зависит от версии):
   - **JWKS-документ**: `dotnet run --project src/OAuthM2M.Cli -c Release -- --config config/avanpost-fam.private_key_jwt.json --PrintJwks=true` — выводит публичный JWKS с `kid` = `OAuth:KeyId`;
   - **сертификат / публичный ключ в PEM**: `./scripts/gen-keys.sh` создаёт `client.crt` и `public.pem`.
4. Выдать клиенту нужные scope/роли.

Клиент:

```bash
./scripts/gen-keys.sh ./secrets my-service
cp config/avanpost-fam.private_key_jwt.json config/my.json
# заполните TokenEndpoint, Audience (token_endpoint или issuer из discovery), ClientId, KeyId, при необходимости ServerCaCertificatePath
dotnet run --project src/OAuthM2M.Cli -c Release -- --config config/my.json
```

`kid` в заголовке JWT (`OAuth:KeyId`) должен совпадать с `kid` ключа, зарегистрированного на сервере.
Если на `aud` сервер отвечает `invalid_client` — попробуйте второе значение (token_endpoint ↔ issuer).

## 3. mTLS

На стороне FAM нужно:

1. Чтобы TLS на токен-эндпоинте **запрашивал клиентский сертификат** и доверял УЦ, выпустившему сертификат клиента
   (для теста: `ca.crt` из `scripts/gen-mtls-certs.sh`).
2. Клиент зарегистрирован с методом **tls_client_auth** (УЦ-сертификат) или **self_signed_tls_client_auth** (самоподписанный), и сервер умеет сопоставить
   сертификат с клиентом (по subject DN / SAN / отпечатку — как настроено в FAM).
3. Если перед FAM стоит балансировщик/прокси, он должен либо пропускать mTLS насквозь, либо проверять сертификат и передавать его в FAM
   (иначе сертификат до FAM не дойдёт).

Клиент:

```bash
./scripts/gen-mtls-certs.sh ./secrets/mtls my-service changeit   # или используйте сертификат вашего корпоративного УЦ
cp config/avanpost-fam.mtls.json config/my-mtls.json
# заполните TokenEndpoint и пути к сертификату/СА
dotnet run --project src/OAuthM2M.Cli -c Release -- --config config/my-mtls.json
```

Для корпоративного УЦ с PEM-файлами укажите `ClientCertificatePath` (crt) и `ClientCertificateKeyPath` (key);
для PFX — `ClientCertificatePath` и `ClientCertificatePassword`.

## 4. Проверка curl'ом (если клиент отказывает)

```bash
# mTLS
curl -v --cacert corp-root-ca.crt --cert secrets/mtls/client.crt --key secrets/mtls/client.key \
  -d grant_type=client_credentials -d client_id=my-service "<token_endpoint>"
```

Если curl работает, а клиент нет — сверяйте `ClientId`, формат сертификата и пути. Если не работает и curl — вопрос в настройке FAM/прокси.
