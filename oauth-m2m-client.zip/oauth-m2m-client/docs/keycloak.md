# Keycloak: настройка клиента

Названия пунктов приведены для админ-консоли Keycloak 26.x; в других версиях подписи могут слегка отличаться.
Параметры сервера для mTLS сверяйте с Server Administration Guide вашей версии.

## 0. Локальный Keycloak для проверки (необязательно)

```bash
docker run --rm -p 8080:8080 \
  -e KC_BOOTSTRAP_ADMIN_USERNAME=admin -e KC_BOOTSTRAP_ADMIN_PASSWORD=admin \
  quay.io/keycloak/keycloak:26.0 start-dev
```

Консоль: http://localhost:8080 (admin / admin). Создайте realm `demo`. Токен-эндпоинт:
`http://localhost:8080/realms/demo/protocol/openid-connect/token` — http допустим только для localhost и только в режиме `PrivateKeyJwt`.
Для mTLS нужен HTTPS (см. ниже).

## 1. private_key_jwt

1. `./scripts/gen-keys.sh ./secrets my-service` — получите `private.pem`, `public.pem`, `client.crt`.
2. **Clients → Create client**: Client type `OpenID Connect`, Client ID `my-service` → Next.
   **Client authentication = On**; в «Authentication flow» оставьте только **Service accounts roles** → Save.
3. Вкладка **Credentials** → **Client Authenticator = Signed JWT** → Save.
4. Вкладка **Keys** → выключите *Use JWKS URL* → **Import key** (или «Import») → формат **Certificate PEM** → вставьте содержимое `secrets/client.crt` → Confirm.
   Альтернатива — JWKS: `dotnet run --project src/OAuthM2M.Cli -- --config config/my.json --PrintJwks=true`, положите вывод на URL, доступный Keycloak, включите *Use JWKS URL* и укажите его. `kid` в документе совпадает с `OAuth:KeyId`.
5. Вкладка **Service accounts roles**: назначьте нужные роли сервисному аккаунту.
6. Клиент:

```bash
export OAuth__TokenEndpoint="https://keycloak.example.com/realms/demo/protocol/openid-connect/token"
export OAuth__Audience="https://keycloak.example.com/realms/demo"
export OAuth__ClientId=my-service
export OAuth__KeyId=my-key-1
export OAuth__PrivateKeyPath=./secrets/private.pem
dotnet run --project src/OAuthM2M.Cli -c Release
```

**Про `aud`.** В Keycloak 26 допустимы issuer realm'а (`https://host/realms/demo`) или URL токен-эндпоинта; `aud` должен быть одной строкой
(клиент всегда шлёт одну). Рекомендуется issuer. Если не задан `OAuth:Audience`, используется токен-эндпоинт.

**Про `kid`.** При импорте сертификата Keycloak сам определяет ключ клиента; при ошибке про ключ/подпись попробуйте JWKS URL —
там `kid` задан явно и совпадает с `OAuth:KeyId`. Подробности — в [troubleshooting.md](troubleshooting.md).

## 2. mTLS (X.509 клиентская аутентификация)

Сертификат клиента должен быть выдан УЦ, которому доверяет Keycloak.

1. `./scripts/gen-mtls-certs.sh ./secrets/mtls my-service changeit` — тестовый СА, клиентский сертификат и PFX.
2. Сервер Keycloak должен слушать HTTPS и запрашивать клиентский сертификат, например:

```bash
kc.sh start \
  --https-certificate-file=/certs/server.crt --https-certificate-key-file=/certs/server.key \
  --https-client-auth=request \
  --https-trust-store-file=/certs/truststore.p12 --https-trust-store-password=changeit \
  --hostname=keycloak.example.com
```

   Trust store должен содержать `ca.crt`:
   `keytool -importcert -alias m2m-ca -file ca.crt -keystore truststore.p12 -storetype PKCS12 -storepass changeit`.
   `--https-client-auth=request` (сертификат по желанию) подходит, если на том же хосте работают и браузерные входы; `required` — для выделенного узла.
3. За обратным прокси (nginx/HAProxy/Ingress) TLS обычно терминируется на прокси: он должен проверять клиентский сертификат и передавать его Keycloak
   заголовком, а у Keycloak включается соответствующий `x509cert-lookup` провайдер (`--spi-x509cert-lookup--provider=nginx|haproxy|apache`
   плюс `--proxy-headers`). Без этого сертификат до Keycloak не дойдёт (признак — `invalid_client`, хотя сертификат валиден).
4. **Clients → Create client** → `my-service`, **Client authentication = On**, **Service accounts roles**.
5. **Credentials → Client Authenticator = X509 Certificate**. Поле **Subject DN** — `CN=my-service`
   (для шаблона включите «Allow regex pattern comparison»). Save.
6. Клиент:

```bash
export OAuth__AuthMethod=TlsClientAuth
export OAuth__TokenEndpoint="https://keycloak.example.com:8443/realms/demo/protocol/openid-connect/token"
export OAuth__ClientId=my-service
export OAuth__ClientCertificatePath=./secrets/mtls/client.pfx
export OAuth__ClientCertificatePassword=changeit
export OAuth__ServerCaCertificatePath=./secrets/mtls/ca.crt    # только если сервер подписан непубличным СА
dotnet run --project src/OAuthM2M.Cli -c Release
```

## 3. Проверка без .NET (curl)

```bash
# mTLS
curl -v --cacert secrets/mtls/ca.crt --cert secrets/mtls/client.crt --key secrets/mtls/client.key \
  -d grant_type=client_credentials -d client_id=my-service \
  https://keycloak.example.com:8443/realms/demo/protocol/openid-connect/token
```
