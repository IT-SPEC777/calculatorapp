# oauth-m2m-client

Консольный M2M-клиент OAuth 2.0 / OIDC на .NET: получает `access_token` по `client_credentials`
без `client_secret`. Два режима аутентификации клиента:

| Режим | Стандарт | Как клиент доказывает личность |
|---|---|---|
| `PrivateKeyJwt` (по умолчанию) | RFC 7523, OIDC Core §9 | подписанный RS256-JWT в `client_assertion` |
| `TlsClientAuth` | RFC 8705 (`tls_client_auth`) | клиентский сертификат в TLS-рукопожатии (mTLS) |

Серверы: **Keycloak**, **Avanpost FAM** (и любой OIDC-провайдер с этими методами).

- Приватный ключ никогда не уходит по сети и не хранится в коде — только путь к файлу.
- RSA-2048+ (ключ короче отвергается). JWT живёт 60–300 с (по умолчанию 120), `jti` — новый GUID на каждый запрос.
- `HttpClient` создаётся через `IHttpClientFactory` (без socket exhaustion).
- Токен в консоль выводится замаскированным; полностью — только с `--PrintToken=true`.

## Структура

```
OAuthM2M.sln
gitflic-ci.yaml                  пайплайн GitFlic (build → test → publish)
global.json, nuget.config
Directory.Build.props            общие свойства сборки (TFM, nullable, анализаторы)
Directory.Packages.props         версии NuGet-пакетов (Central Package Management)
src/OAuthM2M.Client/             библиотека: JWT, mTLS, токен-клиент, DI
src/OAuthM2M.Cli/                консольное приложение (oauth-m2m)
tests/OAuthM2M.Client.Tests/     xUnit-тесты
config/                          примеры конфигураций для 4 сценариев
scripts/                         gen-keys.sh, gen-mtls-certs.sh (OpenSSL)
docs/                            keycloak.md, avanpost-fam.md, troubleshooting.md
```

## Требования

- **.NET SDK 10** (LTS) — целевая платформа по умолчанию `net10.0`.
- Нужен .NET 8? Работает без правок кода:
  `dotnet build -p:TargetFramework=net8.0` и `dotnet run -f net8.0 --project src/OAuthM2M.Cli`.
  (.NET 8 заканчивает поддержку 10 ноября 2026 — для новых проектов лучше 10.)
- OpenSSL (для скриптов генерации ключей). На Windows — через Git Bash.
- Docker — только если хотите локальный Keycloak для проверки.

## Быстрый старт

```bash
dotnet restore
dotnet build -c Release
dotnet test  -c Release          # юнит-тесты не требуют сети и серверов
```

Запуск (общий вид):

```bash
dotnet run --project src/OAuthM2M.Cli -c Release -- --config config/<файл>.json
```

Коды возврата: `0` — токен получен, `1` — ошибка (сервер/сеть/ключ), `2` — ошибка конфигурации, `130` — Ctrl+C.

## Конфигурация

Приоритет (от низшего к высшему): `appsettings.json` → `--config файл.json` → переменные окружения → аргументы командной строки.
Параметры лежат в секции `OAuth`; в переменных окружения вместо `:` используется `__`.

| Параметр | Режим | Описание |
|---|---|---|
| `TokenEndpoint` | оба | URL токен-эндпоинта. Только https (http — только для localhost, и не для mTLS) |
| `ClientId` | оба | `client_id` сервиса |
| `AuthMethod` | оба | `PrivateKeyJwt` (по умолчанию) или `TlsClientAuth` |
| `Scope` | оба | необязательный scope |
| `KeyId` | JWT | `kid` в заголовке JWT |
| `PrivateKeyPath` | JWT | путь к приватному ключу RSA (PEM, PKCS#8/PKCS#1) |
| `PrivateKeyPassword` | JWT | пароль, если ключ зашифрован (передавайте через переменную окружения) |
| `Audience` | JWT | `aud`; по умолчанию = `TokenEndpoint` |
| `AssertionLifetimeSeconds` | JWT | 60..300, по умолчанию 120 |
| `ClientCertificatePath` | mTLS | `.pfx/.p12` или PEM-сертификат |
| `ClientCertificateKeyPath` | mTLS | ключ, если сертификат в PEM |
| `ClientCertificatePassword` | mTLS | пароль к PFX / зашифрованному PEM-ключу |
| `ServerCaCertificatePath` | оба | корневой СА сервера, если он не в системном хранилище |
| `HttpTimeoutSeconds` | оба | по умолчанию 30 |

Служебные ключи CLI: `--config=<файл>`, `--PrintToken=true`, `--PrintJwks=true` (публичный JWKS из вашего ключа).

---

## Сценарий 1. Keycloak + private_key_jwt

Подробная настройка сервера — [docs/keycloak.md](docs/keycloak.md).

```bash
# 1) ключи
./scripts/gen-keys.sh ./secrets my-service

# 2) на стороне Keycloak: клиент my-service → Signed JWT → импорт secrets/client.crt (см. docs/keycloak.md)

# 3) запуск
cp config/keycloak.private_key_jwt.json config/my.json     # отредактируйте URL/ClientId/KeyId
dotnet run --project src/OAuthM2M.Cli -c Release -- --config config/my.json
```

То же без файла, на переменных окружения:

```bash
export OAuth__AuthMethod=PrivateKeyJwt
export OAuth__TokenEndpoint="https://keycloak.example.com/realms/demo/protocol/openid-connect/token"
export OAuth__Audience="https://keycloak.example.com/realms/demo"   # issuer; для старых версий можно опустить (= токен-эндпоинт)
export OAuth__ClientId=my-service
export OAuth__KeyId=my-key-1
export OAuth__PrivateKeyPath=./secrets/private.pem
dotnet run --project src/OAuthM2M.Cli -c Release
```

## Сценарий 2. Keycloak + mTLS

```bash
./scripts/gen-mtls-certs.sh ./secrets/mtls my-service changeit
# Keycloak: HTTPS + trust store с ca.crt + клиент с аутентификатором «X509 Certificate» (docs/keycloak.md)

export OAuth__AuthMethod=TlsClientAuth
export OAuth__TokenEndpoint="https://keycloak.example.com:8443/realms/demo/protocol/openid-connect/token"
export OAuth__ClientId=my-service
export OAuth__ClientCertificatePath=./secrets/mtls/client.pfx
export OAuth__ClientCertificatePassword=changeit
export OAuth__ServerCaCertificatePath=./secrets/mtls/ca.crt     # если сертификат сервера выдан не публичным УЦ
dotnet run --project src/OAuthM2M.Cli -c Release
```

## Сценарий 3. Avanpost FAM + private_key_jwt

Чек-лист стороны сервера — [docs/avanpost-fam.md](docs/avanpost-fam.md).

```bash
./scripts/gen-keys.sh ./secrets my-service
# Если FAM регистрирует ключ по JWKS — получите документ из своего ключа:
dotnet run --project src/OAuthM2M.Cli -c Release -- --config config/avanpost-fam.private_key_jwt.json --PrintJwks=true

dotnet run --project src/OAuthM2M.Cli -c Release -- --config config/avanpost-fam.private_key_jwt.json
```

## Сценарий 4. Avanpost FAM + mTLS

```bash
# клиентский сертификат должен быть выдан УЦ, которому доверяет FAM (или тестовый СА из scripts/gen-mtls-certs.sh)
dotnet run --project src/OAuthM2M.Cli -c Release -- --config config/avanpost-fam.mtls.json
```

В `config/avanpost-fam.*.json` подставьте `TokenEndpoint` и `Audience` из discovery-документа вашего FAM — см. [docs/avanpost-fam.md](docs/avanpost-fam.md).

---

## Использование как библиотеки

```csharp
services.AddOAuthM2MClient(configuration);          // секция "OAuth"
// ...
var token = await sp.GetRequiredService<IOAuthTokenClient>().RequestTokenAsync(ct);
// token.AccessToken, token.ExpiresIn
```

Кэширование токена в библиотеку не включено намеренно: кэшируйте `AccessToken` до `ExpiresIn − 30..60 с`
и вызывайте `RequestTokenAsync` заново.

## CI/CD в GitFlic

Файл `gitflic-ci.yaml` (имя и расположение — по документации GitFlic): `build` → `test` → `publish`.
Нужен агент (runner) GitFlic с Docker-исполнителем и доступом к `mcr.microsoft.com` и NuGet-источнику.
В закрытом контуре замените образ в `gitflic-ci.yaml` на зеркало и источник в `nuget.config` на внутренний прокси.
Артефакты: `TestResults/` (TRX + покрытие Cobertura) и `publish/oauth-m2m/` (переносимая сборка с `config/`).

## Выгрузка в GitFlic

```bash
cd oauth-m2m-client
git init -b main
git add .
git status                      # убедитесь, что secrets/, *.pem, *.pfx, *.key не попали в индекс
git commit -m "Initial commit: OAuth M2M client (private_key_jwt, mTLS)"
git remote add origin https://gitflic.ru/project/<владелец>/<проект>.git
git push -u origin main
```

Пайплайн запустится автоматически, если для проекта подключён агент.

## Безопасность

- `.gitignore` исключает `secrets/`, `*.pem`, `*.key`, `*.pfx`, `*.p12`. Проверяйте `git status` перед коммитом.
- Пароли к ключам/PFX передавайте через переменные окружения или секреты CI, не через файлы в репозитории.
- В проде храните ключ вне репозитория и образа: смонтированный секрет, Vault, хранилище сертификатов ОС. Для хранилища/Vault замените
  `PrivateKeyLoader`/`ClientCertificateLoader` (интерфейс `IClientAssertionFactory` уже выделен).
- Следите за временем на хосте (NTP): при расхождении больше нескольких секунд сервер отвергнет JWT (`nbf`/`exp`).
- Ротация ключа: добавьте новый ключ на сервер → переключите `KeyId`/`PrivateKeyPath` → удалите старый.

См. также: [docs/troubleshooting.md](docs/troubleshooting.md).
